## Scheduler
Transaktionsverwaltung SS2018

Sebastian Meyer

Das Projekt wurde mit dem shadow Plugin gebaut. Die scheduler-1.0.jar enthält alle notwendigen Daten.

Zum erstellen der Jar kann "gradlew shadowJar" genutzt werden. 